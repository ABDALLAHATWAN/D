//data
const products = [

    {name:"adidss" , price:30 , image : '/shoes3.png'},
    {name:"adiss" , price:10 , image : '/shoes4.png'},
    {name:"adids" , price:20 , image : '/shoes5.png'}

]